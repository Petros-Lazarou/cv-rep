#include <asm-generic/socket.h>

#include "Hotels.c"
#define PORT 4444
#define BUF_SIZE 3500
#define CLADDR_LEN 100
#define MAX_THREADS 5

void *thread_func1(void *arg);
hotel_t *l_Hotels;
pthread_mutex_t l_mutex;
atomic_short thread_fl[MAX_THREADS];
typedef struct thread_args
{
  struct sockaddr_in *addr;
  struct sockaddr_in *cl_addr;
  int sockfd;
  int newsockfd;
  int len;
  int ret;
  int stat;
  int pos;
} arg_th;
typedef struct unique_thread_arg
{
  arg_th *l_thread;
  int num;
  char *buffer;
} u_thread;
void main()
{
  signal(SIGPIPE, SIG_IGN);
  int l_stat;
  void *address = 0;
  struct sockaddr_in addr, cl_addr;
  int sockfd, len, ret, newsockfd;
  char *buffer;
  int j = 0;
  int optval = 1;
  pid_t childpid;
  char clientAddr[CLADDR_LEN];
  pthread_t loc_thread[MAX_THREADS];
  int creation_stat = 0;
  
  for (size_t i = 0; i < MAX_THREADS; i++)
  {
    thread_fl[i] = 2;
  }

  pthread_mutex_init(&l_mutex, NULL);
  l_Hotels = malloc(sizeof(hotel_t) * MAX_HOTELS);
  read_hotels(l_Hotels); 

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0)
  {
    printf("Error creating socket!\n");
    exit(1);
  }
  printf("Socket created...\n");
  
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));
  
  memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = INADDR_ANY;
  addr.sin_port =PORT;

  ret = bind(sockfd, (struct sockaddr *)&addr, sizeof(addr));
  if (ret < 0)
  {
    printf("Error binding!\n");
    exit(1);
  }
  printf("Binding done...\n");
  
  //printHotels(l_Hotels); 
  
  printf("Waiting for a connection...\n");
  listen(sockfd, 10);
  
  while (1)
  {

    while (1)
    {
      if (thread_fl[j] == 2 || thread_fl[j] == 1)
      {
        break;
      }
      j++;
      if (j == MAX_THREADS)
      {
        j = 0;
      }
      sleep(1);
    }
    len = sizeof(cl_addr);
    newsockfd = accept(sockfd, (struct sockaddr *)&cl_addr, &len);
    if (newsockfd < 0)
    {
      printf("Error accepting connection!\n");
    }
    printf("Connection accepted...\n");

    inet_ntop(AF_INET, &(cl_addr.sin_addr), clientAddr, CLADDR_LEN);
    
    
    arg_th *l_thread;
    l_thread = malloc(sizeof(arg_th));
    l_thread->addr = &addr;
    l_thread->cl_addr = &cl_addr;
    l_thread->len = len;
    l_thread->ret = ret;
    l_thread->sockfd = sockfd;
    l_thread->newsockfd = newsockfd;
    u_thread *thread_arguements = malloc(sizeof(u_thread));
    thread_arguements->l_thread = l_thread;
    
    for (size_t i = 0; i < MAX_THREADS; i++)
    {
      if (thread_fl[i] == 1)
      {
        pthread_join(loc_thread[i], &address);
        thread_fl[i] = 2;
      }
      for (size_t i = 0; i < MAX_THREADS; i++)
      {
        if (thread_fl[i] == 2)
        {
          thread_arguements->num = i;
          thread_fl[i] = 0;
          if (!pthread_create(&loc_thread[i], NULL, thread_func1, (void *)thread_arguements))
          {
            creation_stat = 1;
            break;
          };
        }
      }
      if (creation_stat == 1)
      {
        creation_stat = 0;
        break;
      }
    }
  
  }
}
void *thread_func1(void *arg)
{
    current_year = get_currentyear();
    u_thread *thread_struct = (u_thread *)arg;
    arg_th *struct_ptr = thread_struct->l_thread;
    
    thread_struct->buffer = malloc(BUF_SIZE);
    if (thread_struct->buffer == NULL) {
        perror("Failed to allocate thread buffer");
        thread_fl[thread_struct->num] = 1;
        return NULL;
    }

    int number_of_beds = 0, min_price = 0, max_price = 0;
    char Hotel_location[50] = {0}; 
    char *args[4]; 
    pthread_mutex_lock(&l_mutex);
    read_hotels(l_Hotels);
    pthread_mutex_unlock(&l_mutex);

    send(struct_ptr->newsockfd, "READY", 6, 0);
    memset(thread_struct->buffer, 0, BUF_SIZE);
    
    int bytes_received = recv(struct_ptr->newsockfd, thread_struct->buffer, BUF_SIZE - 1, 0);
    if (bytes_received <= 0) {
        printf("Client disconnected before sending initial data.\n");
        goto cleanup;
    thread_struct->buffer[bytes_received] = '\0'; 

    // Extract search arguments safely
    args[0] = strtok(thread_struct->buffer, "\\\n");
    for (size_t i = 1; i < 4; i++) {
        args[i] = strtok(NULL, "\\\n");
    }

    // Verify strtok didn't return NULL before parsing
    if (args[0] && args[1] && args[2] && args[3]) {
        number_of_beds = (int)strtol(args[1], NULL, 10);
        min_price = (int)strtol(args[2], NULL, 10);
        max_price = (int)strtol(args[3], NULL, 10);
        strncpy(Hotel_location, args[0], sizeof(Hotel_location) - 1);
    } else {
        printf("Malformed initial search query.\n");
        goto cleanup;
    }

    hotel_t *eligible_rooms = malloc(sizeof(hotel_t) * MAX_HOTELS); 
    char *info_loc = results_st(l_Hotels, eligible_rooms, Hotel_location, number_of_beds, min_price, max_price);
 
    bzero(thread_struct->buffer, BUF_SIZE);
    if (info_loc != NULL) {
        strncpy(thread_struct->buffer, info_loc, BUF_SIZE - 1);
    }

    if ((send(struct_ptr->newsockfd, thread_struct->buffer, strlen(thread_struct->buffer), 0) == -1)) {
        perror("Error in sending search results");
    }

    char *hotel_name;
    char *room_num;
    int room_number;
    hotel_t *l_hotel = malloc(sizeof(hotel_t));
    room_t *l_room = malloc(sizeof(room_t));

    // Wait for the client to select a valid room
    while(1) {
        bzero(thread_struct->buffer, BUF_SIZE);
        bytes_received = recv(struct_ptr->newsockfd, thread_struct->buffer, BUF_SIZE - 1, 0);
        if (bytes_received <= 0) {
            printf("Client disconnected during room selection.\n");
            goto cleanup;
        }
        thread_struct->buffer[bytes_received] = '\0';
        printf("Received from client: %s\n", thread_struct->buffer);
  
        hotel_name = strtok(thread_struct->buffer, "\\\n");
        room_num = strtok(NULL, "\\\n");

        if (hotel_name == NULL || room_num == NULL) {
            strcpy(thread_struct->buffer, "The information you entered is not valid\n");
            send(struct_ptr->newsockfd, thread_struct->buffer, strlen(thread_struct->buffer), 0);
            continue;
        }

        room_number = (int)strtol(room_num, NULL, 10);

        if (room_hotel_validity(eligible_rooms, l_hotel, l_room, hotel_name, room_number)) {
            printf("Room is valid\n");
            strcpy(thread_struct->buffer, "The room is valid,\n Enter the days you would like to make the reservation.\n");
            send(struct_ptr->newsockfd, thread_struct->buffer, strlen(thread_struct->buffer), 0);
            break;
        } else {
            printf("Room is not valid\n");
            strcpy(thread_struct->buffer, "The information you entered is not valid\n");
            send(struct_ptr->newsockfd, thread_struct->buffer, strlen(thread_struct->buffer), 0);
        }
    }

    bzero(thread_struct->buffer, BUF_SIZE);
    bytes_received = recv(struct_ptr->newsockfd, thread_struct->buffer, BUF_SIZE - 1, 0);
    if (bytes_received <= 0) {
        goto cleanup;
    }
    thread_struct->buffer[bytes_received] = '\0';

    char *reservation_date_st[6]; // Stack array, no malloc needed
    long reservation_date_num[6] = {0};

    reservation_date_st[0] = strtok(thread_struct->buffer,"/\\\n");
    for (size_t i = 1; i < 6; i++) {
        reservation_date_st[i] = strtok(NULL,"\\/ \n");
    }

    int valid_dates = 1;
    for (size_t i = 0; i < 6; i++) {
        if (reservation_date_st[i] == NULL) {
            valid_dates = 0;
            break;
        }
        reservation_date_num[i] = strtol(reservation_date_st[i], NULL, 10);
    }

    if (valid_dates) {
        pthread_mutex_lock(&l_mutex);
        hotel_to_reserve = 0;
        room_to_reserve = 0;
        read_hotels(l_Hotels);
        int l_price = reservation_server(l_Hotels, *l_hotel, *l_room, reservation_date_num);
        
        bzero(thread_struct->buffer, BUF_SIZE);
        if(l_price) {
            char l_price_st[20]; // Stack array
            strcpy(thread_struct->buffer, "You were able to make the reservation and the price is \n");
            sprintf(l_price_st, "%d", l_price);
            strcat(thread_struct->buffer, l_price_st);
            strcat(thread_struct->buffer, "$\n");
            flush_reservations(l_Hotels[hotel_to_reserve].ptr[room_to_reserve].starting_node_l, l_Hotels[hotel_to_reserve].ptr[room_to_reserve], 1);
        } else {
            strcpy(thread_struct->buffer,"You were not able to make the reservation\n");
        }
        send(struct_ptr->newsockfd, thread_struct->buffer, strlen(thread_struct->buffer), 0);
        pthread_mutex_unlock(&l_mutex);
    } else {
        strcpy(thread_struct->buffer, "Invalid date format provided.\n");
        send(struct_ptr->newsockfd, thread_struct->buffer, strlen(thread_struct->buffer), 0);
    }

    bzero(thread_struct->buffer, BUF_SIZE);
    bytes_received = recv(struct_ptr->newsockfd, thread_struct->buffer, BUF_SIZE - 1, 0);
    if (bytes_received > 0) {
        thread_struct->buffer[bytes_received] = '\0';
        if (!strncmp(thread_struct->buffer, "exit", 4)) {
            printf("Client closed connection cleanly.\n");
        }
    }


cleanup:
    if (struct_ptr != NULL) {
        close(struct_ptr->newsockfd);
        free(struct_ptr); 
    }
    
    if (eligible_rooms != NULL) free(eligible_rooms);
    if (l_hotel != NULL) free(l_hotel);
    if (l_room != NULL) free(l_room);
    if (info_loc != NULL) free(info_loc); 
    
    if (thread_struct != NULL) {
        if (thread_struct->buffer != NULL) free(thread_struct->buffer);
        
        int thread_index = thread_struct->num; 
        
        free(thread_struct); 
        
        thread_fl[thread_index] = 1; 
    }
    
    return NULL;
}